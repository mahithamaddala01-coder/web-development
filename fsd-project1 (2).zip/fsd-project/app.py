from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import sqlite3, bcrypt, os
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'fsd-project-secret-key-2024'
DB = 'database.db'

# ── DB INIT ──────────────────────────────────────────────────────────────────
def get_db():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with get_db() as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                subject TEXT NOT NULL,
                message TEXT NOT NULL,
                status TEXT DEFAULT 'unread',
                submitted_at TEXT DEFAULT (datetime('now'))
            );
        ''')
        # Create default admin if not exists
        admin_pw = bcrypt.hashpw(b'admin123', bcrypt.gensalt()).decode()
        try:
            db.execute("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)",
                       ('admin', 'admin@fsd.dev', admin_pw, 'admin'))
            db.commit()
        except:
            pass

init_db()

# ── AUTH DECORATOR ────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'admin':
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

# ── ROUTES ────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        email    = request.form['email'].strip()
        password = request.form['password']
        errors = []
        if len(username) < 3:
            errors.append('Username must be at least 3 characters.')
        if '@' not in email:
            errors.append('Enter a valid email address.')
        if len(password) < 6:
            errors.append('Password must be at least 6 characters.')
        if errors:
            return jsonify({'success': False, 'errors': errors})
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        try:
            with get_db() as db:
                db.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                           (username, email, hashed))
                db.commit()
            return jsonify({'success': True, 'redirect': url_for('login')})
        except sqlite3.IntegrityError:
            return jsonify({'success': False, 'errors': ['Username or email already taken.']})
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and bcrypt.checkpw(password.encode(), user['password'].encode()):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            dest = url_for('admin') if user['role'] == 'admin' else url_for('dashboard')
            return jsonify({'success': True, 'redirect': dest})
        return jsonify({'success': False, 'errors': ['Invalid username or password.']})
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name    = request.form['name'].strip()
        email   = request.form['email'].strip()
        subject = request.form['subject'].strip()
        message = request.form['message'].strip()
        errors = []
        if not name:    errors.append('Name is required.')
        if '@' not in email: errors.append('Enter a valid email.')
        if not subject: errors.append('Subject is required.')
        if len(message) < 10: errors.append('Message must be at least 10 characters.')
        if errors:
            return jsonify({'success': False, 'errors': errors})
        with get_db() as db:
            db.execute("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)",
                       (name, email, subject, message))
            db.commit()
        return jsonify({'success': True, 'message': 'Message sent! We\'ll be in touch.'})
    return render_template('contact.html')

# ── ADMIN ROUTES ──────────────────────────────────────────────────────────────
@app.route('/admin')
@login_required
@admin_required
def admin():
    with get_db() as db:
        users    = db.execute("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC").fetchall()
        contacts = db.execute("SELECT * FROM contacts ORDER BY submitted_at DESC").fetchall()
        stats = {
            'users':    db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
            'contacts': db.execute("SELECT COUNT(*) FROM contacts").fetchone()[0],
            'unread':   db.execute("SELECT COUNT(*) FROM contacts WHERE status='unread'").fetchone()[0],
        }
    return render_template('admin.html', users=users, contacts=contacts, stats=stats)

@app.route('/admin/contact/<int:cid>/read', methods=['POST'])
@login_required
@admin_required
def mark_read(cid):
    with get_db() as db:
        db.execute("UPDATE contacts SET status='read' WHERE id=?", (cid,))
        db.commit()
    return jsonify({'success': True})

@app.route('/admin/contact/<int:cid>/delete', methods=['POST'])
@login_required
@admin_required
def delete_contact(cid):
    with get_db() as db:
        db.execute("DELETE FROM contacts WHERE id=?", (cid,))
        db.commit()
    return jsonify({'success': True})

@app.route('/admin/user/<int:uid>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(uid):
    if uid == session['user_id']:
        return jsonify({'success': False, 'error': "You can't delete yourself."})
    with get_db() as db:
        db.execute("DELETE FROM users WHERE id=?", (uid,))
        db.commit()
    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
