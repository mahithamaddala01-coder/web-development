# Full Stack Development – Project 1

A complete full-stack web application built with **HTML, CSS, JavaScript, Python Flask & SQLite**.

---

## Features
- User Registration & Login (bcrypt password hashing)
- Contact Form → saves to SQLite database
- Admin Dashboard (manage users & messages)
- Session-based authentication
- Responsive design (mobile, tablet, desktop)

---

## Setup & Run

### 1. Install dependencies
```bash
pip install flask bcrypt
```

### 2. Run the server
```bash
python app.py
```

### 3. Open in browser
```
http://localhost:5000
```

---

## Demo Credentials

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| User  | alice    | user123   |
| User  | bob      | user123   |

---

## Project Structure

```
fsd-project/
├── app.py               ← Flask backend + all routes
├── database.db          ← SQLite database (auto-created)
├── static/
│   └── css/style.css    ← Shared stylesheet
└── templates/
    ├── base.html         ← Shared nav + layout
    ├── index.html        ← Home page
    ├── register.html     ← Register form
    ├── login.html        ← Login form
    ├── contact.html      ← Contact form
    ├── dashboard.html    ← Logged-in user view
    └── admin.html        ← Admin dashboard
```

---

## Database Tables

### users
| id | username | email | password (bcrypt) | role | created_at |

### contacts
| id | name | email | subject | message | status | submitted_at |
